package com.thymeleafe.demo.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name="musiccollection")
public class Inventory {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private int id;

    @Column(name="artist_name")
    private String artist_name;

    @Column(name="album_name")
    private String album_name;

    @Column(name="tracks")
    private String tracks;

    public Inventory() {
    }

    public Inventory(int id, String artist_name, String album_name, String numberOfTracks) {
        this.id = id;
        this.artist_name = artist_name;
        this.album_name = album_name;
        this.tracks = numberOfTracks;

    }
}
