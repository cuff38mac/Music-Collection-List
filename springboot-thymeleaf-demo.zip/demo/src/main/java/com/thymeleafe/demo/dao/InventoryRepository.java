package com.thymeleafe.demo.dao;

import com.thymeleafe.demo.entity.Inventory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface InventoryRepository extends JpaRepository<Inventory, Integer> {
    // add a method to sort by last name


}
