package com.thymeleafe.demo.service;

import com.thymeleafe.demo.dao.InventoryRepository;
import com.thymeleafe.demo.entity.Inventory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InventoryServiceImp implements InventoryService{

    private InventoryRepository inventoryRepository;

    @Autowired
    public InventoryServiceImp(InventoryRepository inventoryRepository) {
        this.inventoryRepository = inventoryRepository;
    }

    @Override
    public List<Inventory> findAll() {
        return inventoryRepository.findAll();
    }

    @Override
    public Inventory findById(int theId) {
        Optional<Inventory> result = inventoryRepository.findById(theId);

        Inventory theEmployee = null;

        if (result.isPresent()) {
            theEmployee = result.get();
        }
        else {
            // we didn't find the employee
            throw new RuntimeException("Did not find music item id - " + theId);
        }

        return theEmployee;
    }

    @Override
    public void save(Inventory theEmployee) {
        inventoryRepository.save(theEmployee);
    }

    @Override
    public void deleteById(int theId) {
        inventoryRepository.deleteById(theId);
    }



}






