package com.thymeleafe.demo.service;

import com.thymeleafe.demo.entity.Inventory;

import java.util.List;

public interface InventoryService {

    public List<Inventory> findAll();
    public Inventory findById(int theId);
    public void save(Inventory theInv);
    public void deleteById(int theId);


}
