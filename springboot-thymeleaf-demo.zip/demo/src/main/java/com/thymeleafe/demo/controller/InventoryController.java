package com.thymeleafe.demo.controller;

import com.thymeleafe.demo.entity.Inventory;
import com.thymeleafe.demo.service.InventoryService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

@Controller
public class InventoryController {

   private InventoryService inventoryService;

    public InventoryController(InventoryService theInventoryService) {
        inventoryService = theInventoryService;
    }

    @GetMapping("/showAdd")
    public String showAdd(Model theModel){
        Inventory theInv = new Inventory();
        theModel.addAttribute("musiccollection", theInv);
        return "add-form";
    }

    @PostMapping("/save")
    public String save(@ModelAttribute("musiccollection") Inventory theInventory){
    inventoryService.save(theInventory);
    return "redirect:/list";
    }

    @GetMapping("/delete")
    public String delete(@RequestParam("inventoryId") int theId){
        inventoryService.deleteById(theId);
        return "redirect:/list";
    }

    @GetMapping("/showUpdateForm")
    public String showUpdateForm(@RequestParam("inventoryId") int theId, Model model){
        Inventory theInv = inventoryService.findById(theId);

        model.addAttribute("musiccollection", theInv);

        return "add-form";
    }

    @GetMapping("/list")
    public String showList(Model theModel){
        List<Inventory> inv = inventoryService.findAll();
        theModel.addAttribute("musiccollection", inv);

        return "list-inventory";
    }



}
